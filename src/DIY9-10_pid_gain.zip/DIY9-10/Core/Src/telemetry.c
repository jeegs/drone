/*
 *telemetry.c:
 *
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "telemetry.h"
#include "imu.h"
#include "pid.h"

//Localization of global variables(GPS related):
uint32_t received_telemetry_data1, received_telemetry_data2;
float telemetry_Kp, telemetry_Ki, telemetry_Kd;
uint8_t battCell;
uint8_t error;

//Local variables:
uint8_t   _check_sum;
uint8_t   _8bit_data;
uint32_t _32bit_buffer;
uint8_t _cnt;

void telemetry(void) {
	if (usart1_rx_flag == 1) {
		usart1_rx_flag = 0;
		receive_telemetry(); //9바이트 인터럽트 수신
	}
	if (loop_counter % 6 == 0) {
		send_telemetry(38*6); //38바이트 순차적 폴링 송신
	}
	if (loop_counter % 1 == 0) {
		//printf("%f \n", baro.complementary_pressure);
	}

}
void receive_telemetry(void)
{
	if (received_telemetry_data1 == 119 && received_telemetry_data2 == 911) {
		//ARMED = 0;
	}
	else if (received_telemetry_data1 == 99 && received_telemetry_data2 == 99) {
		LL_GPIO_TogglePin(GPIOE, LED_Red_Pin);
	} else {
		if (flightMode == 1 && ARMED == 0) { //save GPS latLon from APP at RAM:
		}
	}
}

void send_telemetry(uint16_t during) {
	_cnt++;
	if (_cnt == 1)
		_8bit_data = 'G';
	if (_cnt == 2)
		_8bit_data = 'S';

	//errorTV[0]
	if (_cnt == 3) {
		_check_sum = 0;
		_8bit_data = error;
	}

	//batteryTV[1]
	if (_cnt == 4) {
		_32bit_buffer = battery_voltage * 100;
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 5)
		_8bit_data = _32bit_buffer >> 8;

	//fc_gps_latTV[2]
	if (_cnt == 6) {
		_32bit_buffer = 0;//gps.lat_final;
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 7)
		_8bit_data = _32bit_buffer >> 8;
	if (_cnt == 8)
		_8bit_data = _32bit_buffer >> 16;
	if (_cnt == 9)
		_8bit_data = _32bit_buffer >> 24;

	//fc_gps_lonTV[3]
	if (_cnt == 10) {
		_32bit_buffer = 0;//gps.lon_final;
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 11)
		_8bit_data = _32bit_buffer >> 8;
	if (_cnt == 12)
		_8bit_data = _32bit_buffer >> 16;
	if (_cnt == 13)
		_8bit_data = _32bit_buffer >> 24;

	//dest_gps_latTV[4]
	if (_cnt == 14) {
		_32bit_buffer = 0;//dest_gps_lat;
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 15)
		_8bit_data = _32bit_buffer >> 8;
	if (_cnt == 16)
		_8bit_data = _32bit_buffer >> 16;
	if (_cnt == 17)
		_8bit_data = _32bit_buffer >> 24;

	//dest_gps_lonTV[5]
	if (_cnt == 18) {
		_32bit_buffer = 0;//dest_gps_lon;
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 19)
		_8bit_data = _32bit_buffer >> 8;
	if (_cnt == 20)
		_8bit_data = _32bit_buffer >> 16;
	if (_cnt == 21)
		_8bit_data = _32bit_buffer >> 24;

	//satelliteTV[6]
	if (_cnt == 22)
		_8bit_data = 0;//gps.satellite;

	//speedTV[7]
	if (_cnt == 23)
		_8bit_data = 0;//gps.speed; //m/s

	//altitudeTV[8]
	if (_cnt == 24) {
		_32bit_buffer = 0;
		if (ARMED == 2 && flightMode > 1) {
			_32bit_buffer = 0;
		}
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 25)
		_8bit_data = _32bit_buffer >> 8;
	if (_cnt == 26)
		_8bit_data = _32bit_buffer >> 16;
	if (_cnt == 27)
		_8bit_data = _32bit_buffer >> 24;

	//flight_modeTV[9] //------------------------------------------------------------------------>
	if (_cnt == 28) {
		if (ARMED == 0) _8bit_data = flightMode;
		if (ARMED == 2) _8bit_data = flightMode + 32;
	}

	//gps_nextWPointTV[10]
	if (_cnt == 29)
		_8bit_data = 0;//nextWPoint;

	//heading_rockTV[11]
	if (_cnt == 30)
		_8bit_data = extendedMode;//heading_lock;

	//p_gainTV[12]
	if (_cnt == 31)
		_8bit_data = telemetry_Kp * 10; //1.5 * 10 = 15

	//i_gainTV[13]: into 2Byte 2021-12-11 revised.
	if (_cnt == 32) {
		_32bit_buffer = telemetry_Ki * 1000000; //range: ()
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 33)
		_8bit_data = _32bit_buffer >> 8;

	//d_gainTV[14] ----------------> use _16bit_buffer to save memory: (    )
	if (_cnt == 34) {
		_32bit_buffer = telemetry_Kd * 10; //into 2Byte 2021-12-11 revised.
		_8bit_data = _32bit_buffer;
	}
	if (_cnt == 35)
		_8bit_data = _32bit_buffer >> 8;

	//gps_waypoint_cnt[15]
	if (_cnt == 36)
		_8bit_data = 0;//gps_waypoint_cnt;

	//batt_cell[16]
	if (_cnt == 37)
		_8bit_data = battCell;

	//@ _check_sum:
	if (_cnt == 38)
		_8bit_data = _check_sum;

	if (_cnt <= 38) {
		_check_sum ^= _8bit_data;
		LL_USART_TransmitData8(USART1, _8bit_data);
	}
	if (_cnt == during)
		_cnt = 0;
}
