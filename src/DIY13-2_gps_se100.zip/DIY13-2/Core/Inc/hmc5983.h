/*
 * hnc5983.h
 *
 *  Created on: Mar 27, 2022
 *      Author: gyoos
 */

#ifndef INC_HNC5983_H_
#define INC_HNC5983_H_

#include "main.h"
extern I2C_HandleTypeDef hi2c1;
extern float compass_yaw;

typedef struct {
	int16_t x;
	int16_t y;
	int16_t z;
} hmc5983_xyz;
extern hmc5983_xyz compass;

void compass_init(void);
int8_t compass_i2c_write(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len);
int8_t compass_i2c_read(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len);
void make_compass_yawAngle(void);
float compass_no_tilt(void);
float compass_tilt_correction(float roll, float pitch);
float compass_correct_angle(float heading);


#endif /* INC_HNC5983_H_ */

