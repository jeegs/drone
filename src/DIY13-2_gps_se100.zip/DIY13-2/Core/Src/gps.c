/*
 * gps.c:
 *
 * Some ideas borrowed from Joob Brokking: http://brokking.net.
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "user.h"
#include "imu.h"
#include "main.h"
#include "gps.h"
#include "pid.h"
#include "ms5611.h"

//Localization of global variables ----------------------------------> start:
neo_M8N gps;
uint8_t usart3_rx_dma_buffer[DMA_BUFFER_SIZE];//100
float gps_pid_pitch_out;
float gps_pid_roll_out;
uint32_t dest_gps_lat;
uint32_t dest_gps_lon;
uint32_t follow_lat;
uint32_t follow_lon;
float dest_lat_buffer[30];
float dest_lon_buffer[30];
uint8_t gps_waypoint_cnt;
uint8_t satellite;
uint8_t speed;
uint8_t nextWPoint;
//@RTH:
int32_t gps_home_lat;
int32_t gps_home_lon;
uint8_t home_pointed;

uint8_t gps_enabled;
//Localization of global variables ----------------------------------> end:
//Local variables ------------------------------------------------------> start:
#define GPS_HZ 10
#define FC_HZ 1000

uint8_t usart3_rx_data[DMA_BUFFER_SIZE];//100
uint8_t usart3_previous;
uint8_t usart3_rx_cnt;
unsigned char gps_checksum1, gps_checksum2;
//uint8_t gps_enabled;
uint8_t gps_error_cnt;
int8_t gps_hz_controller;
uint8_t gps_mem_cnt;

int32_t lat_braker, lon_braker;
int32_t lat_mem[GPS_BRAKER_BUF_SIZE];
int32_t lon_mem[GPS_BRAKER_BUF_SIZE];

uint32_t gps_watchdog_timer;
int32_t gps_lat, gps_lon;
int32_t gps_lat_prev, gps_lon_prev;
uint32_t gps_pos[2];

float lat_move, lon_move, gps_heading;
float lat_delta, lon_delta;
float lat_fragment, lon_fragment;

//@gps_watchdog:
uint16_t gps_watchdog_start, gps_watchdog_clocks;

//Local variables ------------------------------------------------------> end:

void make_gps_setpoints(void)
{
	gps_enabled = gps_raw_read();
	if(gps_enabled) {//10Hz
		gps_upgrade_ready(200);
		gps_watchdog_start = LL_TIM_GetCounter(TIM14);//TIM14: 1Hz
	} else {
		gps_enabled = gps_upgrade(200);//cf. 10Hz:100ms = 200Hz:5ms
	}

	if (gps_enabled) {
		//LL_GPIO_TogglePin(GPIOE, LED_Green_Pin);//200Hz
		if (flightMode >= 3 && gps.setpointed == 0) {
			gps.setpointed = 1;
			gps.lat_setpoint = gps.lat_final;
			gps.lon_setpoint = gps.lon_final;
		}
		if (flightMode >= 3 && gps.setpointed == 1) {
			if (flightMode == 3){
				gps_setpoint_change_by_USER();
			}
			gps_setpoint_change_apply();
			gps_single_PID();
		}
	}

	//@GPS_watchdog:
	if (gps_enabled == 0) {
		gps_watchdog_clocks = LL_TIM_GetCounter(TIM14) - gps_watchdog_start;
		if (gps_watchdog_clocks > 1600) {//TIM14's one clock:0.5ms, 1600 * 0.5ms = 800ms
			if (flightMode >= 3 && ARMED == 2) {
				flightMode = 2;
				error = 70;//App needs change: (    )
			}
		}
	}

	if (flightMode < 3 && gps.setpointed > 0) gps_reset();
}

uint8_t gps_raw_read(void){
	uint8_t rx_buffer[DMA_BUFFER_SIZE];
	uint8_t current_pos;
	static uint8_t prev_pos = 0;
	uint8_t rx_buffer_size = 0;
	uint8_t gps_parsing_ok = 0;

	current_pos = DMA_BUFFER_SIZE - dma_empty_buffer;//At first, 0 = 100 - 100
	if(current_pos != prev_pos) {
		//printf("%u = %u - %lu   (%u)  \n", current_pos, DMA_BUFFER_SIZE, dma_empty_buffer, gps.satellite); // debugging:
		if(current_pos > prev_pos) {
			memcpy(rx_buffer, &usart3_rx_dma_buffer[prev_pos], current_pos - prev_pos);
			rx_buffer_size += current_pos - prev_pos;
		} else {
			memcpy(rx_buffer, &usart3_rx_dma_buffer[prev_pos], DMA_BUFFER_SIZE - prev_pos);
			rx_buffer_size += DMA_BUFFER_SIZE - prev_pos;
		}
		prev_pos = current_pos;
		if (rx_buffer_size > 0) {
			for (uint8_t i = 0; i < rx_buffer_size; i++) {
				gps_parsing_ok = gps_parsing(i, rx_buffer);//When one packet parsing finished:2022-03-29
			}
		}
	}
	return  gps_parsing_ok;
}

uint8_t gps_parsing(uint8_t i, uint8_t *rx_buff) {//[DMA_BUFFER_SIZE]) {
	uint8_t parsing_finished = 0;

	if (usart3_previous == 0xB5 && rx_buff[i] == 0x62) {
		usart3_rx_cnt = 0;
	} else {
		usart3_previous = rx_buff[i];
		usart3_rx_data[usart3_rx_cnt] = rx_buff[i];
		usart3_rx_cnt++;
		if (usart3_rx_cnt > 97) {
			usart3_rx_cnt = 0;
			gps_checksum1 = 0;
			gps_checksum2 = 0;
			for (uint8_t i = 0; i <= 95; i++) {
				gps_checksum1 += usart3_rx_data[i];
				gps_checksum2 += gps_checksum1;
			}

			if (gps_checksum1 == usart3_rx_data[96] && gps_checksum2 == usart3_rx_data[97]) {
				gps_pos[0] = usart3_rx_data[35] << 24 | usart3_rx_data[34] << 16 | usart3_rx_data[33] << 8 | usart3_rx_data[32];
				gps_pos[1] = usart3_rx_data[31] << 24 | usart3_rx_data[30] << 16 	| usart3_rx_data[29] << 8 | usart3_rx_data[28];

				gps.fix_type = usart3_rx_data[24];
				gps.satellite = usart3_rx_data[27];
				gps.speed = (float) (usart3_rx_data[67] << 24 | usart3_rx_data[66] << 16 | usart3_rx_data[65] << 8 | usart3_rx_data[64]) / 1000; //m/s:

				gps_lat = gps_pos[0];
				gps_lon = gps_pos[1];

				gps_lat /= 10;//37123456
				gps_lon /= 10;//127123456
				if (gps.fix_type == 3 && gps.satellite >= 5) {//cf. 10Hz:100ms = 200Hz:5ms
					parsing_finished = 1;
				}
			} else {
				gps_error_cnt++;
			}
		}
	}
	return parsing_finished;
}

void gps_upgrade_ready(uint16_t upgrade_hz) //void gps_hz_ready(200)
{
	uint8_t divider = upgrade_hz / GPS_HZ;//200/10 = 20, 500/10 = 50, 250/10 = 25

	lat_fragment = (float) (gps_lat - gps_lat_prev) / divider;
	lon_fragment = (float) (gps_lon - gps_lon_prev) / divider;

	gps.lat_final = gps_lat_prev; //(previous)*--------------------*(current) 100ms delay:
	gps.lon_final = gps_lon_prev;

	gps_lat_prev = gps_lat;
	gps_lon_prev = gps_lon;

	gps_hz_controller = divider - 1;//19, 49, 24
	lat_delta = 0;
	lon_delta = 0;
}

uint8_t  gps_upgrade(uint16_t upgrade_hz)
{
	uint8_t hz_control_ok = 0;
	uint8_t gps_delta_term = FC_HZ / upgrade_hz;//1000/200 = 5
	if (gps_hz_controller > 0 && loop_counter % gps_delta_term == 0) {//10Hz:100ms = 200Hz:5ms
		gps_hz_controller--;
		hz_control_ok = 1;
		lat_delta += lat_fragment;
		if (abs(lat_delta) >= 1) {
			gps.lat_final += (int) lat_delta;
			lat_delta -= (int) lat_delta;
		}

		lon_delta += lon_fragment;
		if (abs(lon_delta) >= 1) {
			gps.lon_final += (int) lon_delta;
			lon_delta -= (int) lon_delta;
		}
	}
	return hz_control_ok;
}

void gps_setpoint_change_by_USER(void) {
	if (extendedMode == 1) gps_heading = takeoff_heading_angle; //Heading Lock:
	else 	gps_heading = gyroAngle.z;
	//@When GPS holding only: The South_Korea is at North latitude and East longitude position.
	lat_move -= 0.0015 * (((CH2 - 1500) * cos(gps_heading * 0.01745329f)) + ((CH1 - 1500) * cos((gps_heading - 90) * 0.017453))); //North correction
	lon_move += (0.0015 	* (((CH1 - 1500) * cos(gps_heading * 0.01745329f)) 	+ ((CH2 - 1500) 	* cos((gps_heading + 90) * 0.01745329f)))) / cos(((float) gps.lat_final / 1000000.0) * 0.01745329f); //East correction
}

void gps_setpoint_change_apply(void) {
	//@ user | GPS:
	if (lat_move > 1) {
		gps.lat_setpoint++;
		lat_move--;
	}
	if (lat_move < -1) {
		gps.lat_setpoint--;
		lat_move++;
	}
	if (lon_move > 1) {
		gps.lon_setpoint++;
		lon_move--;
	}
	if (lon_move < -1) {
		gps.lon_setpoint--;
		lon_move++;
	}

}

void gps_single_PID(void) {

	float gps_pitch_dir, gps_roll_dir;

	//@PID error:
	gps.lat_error = gps.lat_final - gps.lat_setpoint;
	gps.lon_error = gps.lon_setpoint - gps.lon_final;

	//brake_lat:
	lat_braker -= lat_mem[gps_mem_cnt];//gps_brake_cnt???
	lat_mem[gps_mem_cnt] = gps.lat_error - gps.prev_lat_error;
	lat_braker += lat_mem[gps_mem_cnt];
    //brake_lon:
	lon_braker -= lon_mem[gps_mem_cnt];
	lon_mem[gps_mem_cnt] = gps.lon_error - gps.prev_lon_error;
	lon_braker += lon_mem[gps_mem_cnt];
	gps.prev_lat_error = gps.lat_error;
	gps.prev_lon_error = gps.lon_error;
	gps_mem_cnt++;
	if (gps_mem_cnt == GPS_BRAKER_BUF_SIZE) {//35->70, The original: 35
		gps_mem_cnt = 0;
	}

	gps.lat_propotional = gps.Kp * gps.lat_error;
	gps.lon_propotional = gps.Kp * gps.lon_error;
	gps.lat_integral += gps.Ki * gps.lat_error;
	gps.lon_integral += gps.Ki * gps.lon_error;
	gps.lat_integral = restrict_max(gps.lat_integral, 300);
	gps.lon_integral = restrict_max(gps.lon_integral, 300);

	gps.lat_derivative = (float)gps.Kd * lat_braker;
	gps.lon_derivative = (float)gps.Kd *lon_braker;

	//Calculate the GPS roll && pitch correction as if the nose of the_Quad is facing north.
	gps_roll_dir = gps.lon_propotional + gps.lon_integral + gps.lon_derivative;//roll
	gps_pitch_dir = gps.lat_propotional + gps.lat_integral + gps.lat_derivative;//pitch

	//@Jee's Algorithm:
	gps_pid_roll_out = gps_roll_dir * cos(gyroAngle.z * 0.0174532925f) + gps_pitch_dir * sin(gyroAngle.z * 0.0174532925f);
	gps_pid_pitch_out = gps_pitch_dir * cos(gyroAngle.z * 0.0174532925f) - gps_roll_dir * sin(gyroAngle.z * 0.0174532925f);

	//Limit the maximum correction to 300. This way we still have full controll with the pitch and roll stick on the transmitter.
	gps_pid_roll_out = restrict_max(gps_pid_roll_out, 300);
	gps_pid_pitch_out = restrict_max(gps_pid_pitch_out, 300);
}

void gps_reset(void) {

	for (uint8_t i = 0; i < GPS_BRAKER_BUF_SIZE; i++) {
		lon_mem[i] = 0;
		lat_mem[i] = 0;
	}

	lat_braker = 0;
	lon_braker = 0;
	gps_mem_cnt = 0;
	gps_pid_roll_out = 0;
	gps_pid_pitch_out = 0;
	gps.setpointed = 0;
	gps.prev_lat_error = 0;
	gps.prev_lon_error = 0;
	gps.lat_setpoint = 0;
	gps.lon_setpoint = 0;
}
