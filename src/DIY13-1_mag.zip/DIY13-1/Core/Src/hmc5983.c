/*
 * hmc5983.c:
 *
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "user.h"
#include "hmc5983.h"
#include "imu.h"

//Localization of global variables:
hmc5983_xyz compass;
float compass_yaw;
float compass_yaw_notilt; //for just debugging:

//Local:
uint8_t compass_rawData[6];

void compass_init(void) {
	uint8_t hmc5983_Hz = 0xFC; //1111 1100(0xFC) : 220Hz
	uint8_t hmc5983_Gaus = 0x20; //+-1.3Gaus:
	uint8_t hmc5983_Mode = 0x00; //continuous
	compass_i2c_write(0x1E, 0x00, &hmc5983_Hz, 1);
	compass_i2c_write(0x1E, 0x01, &hmc5983_Gaus, 1);
	compass_i2c_write(0x1E, 0x02, &hmc5983_Mode, 1);
}

int8_t compass_i2c_write(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len) {
	int8_t *buf;
	buf = malloc(len + 1);
	buf[0] = reg_addr;
	memcpy(buf + 1, data, len);

	if (HAL_I2C_Master_Transmit(&hi2c1, (id << 1), (uint8_t*) buf, len + 1,
	HAL_MAX_DELAY) != HAL_OK)
		return -1;
	free(buf);
	return 0;
}

// Read byte from register
int8_t compass_i2c_read(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len) {
	if (HAL_I2C_Master_Transmit(&hi2c1, (id << 1), &reg_addr, 1, 10) != HAL_OK)
		return -1;
	if (HAL_I2C_Master_Receive(&hi2c1, (id << 1) | 0x01, data, len, 10)
			!= HAL_OK)
		return -1;
	return 0;
}

/*
 #define HMC5883L_REG_OUT_X_M          (0x03)
 #define HMC5883L_REG_OUT_X_L          (0x04)
 #define HMC5883L_REG_OUT_Z_M          (0x05)
 #define HMC5883L_REG_OUT_Z_L          (0x06)
 #define HMC5883L_REG_OUT_Y_M          (0x07)
 #define HMC5883L_REG_OUT_Y_L          (0x08)
 */

void make_compass_yawAngle(void) {
	compass_i2c_read(0x1E, 0x03, compass_rawData, 6);
	compass.y = compass_rawData[0] << 8 | compass_rawData[1];
	compass.y *= -1;
	compass.z = compass_rawData[2] << 8 | compass_rawData[3];
	compass.x = compass_rawData[4] << 8 | compass_rawData[5];
	compass.x *= -1;

	compass_yaw = compass_tilt_correction(gyroAngle.x, gyroAngle.y);
	//compass_yaw_notilt = compass_no_tilt(); //for just debugging:
}

// No tilt compensation
float compass_no_tilt(void) {
	float heading = atan2(compass.y, compass.x);
	float declinationAngle = (-8.26 + (26.0 / 60.0)) / (180 / M_PI);
	heading += declinationAngle;
	heading = compass_correct_angle(heading);
	// Convert to degrees
	heading = heading * 180 / M_PI;
	return heading;
}

// Tilt compensation
float compass_tilt_correction(float roll, float pitch) {

	float heading;

	float Xh = (float) compass.x * cos(pitch * -0.0174533) + (float) compass.y * sin(roll * 0.0174533)	* sin(pitch * -0.0174533) - (float) compass.z * cos(roll * 0.0174533)	* sin(pitch * -0.0174533);
	float Yh = (float) compass.y * cos(roll * 0.0174533) + (float) compass.z * sin(roll * 0.0174533);

	if (Yh < 0)
		heading = 180 + (180 + ((atan2(Yh, Xh)) * (180 / M_PI)));
	else
		heading = (atan2(Yh, Xh)) * (180 / M_PI);

	heading += -8.29;//Jecheon_city:
	heading += 360;

	if (heading < 0) heading += 360;
	else if (heading >= 360) heading -= 360;
	return heading;
}

// Correct angle
#define PI 3.14159
float compass_correct_angle(float heading) {
	if (heading < 0) {
		heading += 2 * PI;
	}
	if (heading > 2 * PI) {
		heading -= 2 * PI;
	}
	return heading;
}

