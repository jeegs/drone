/*
 * user.h
 *
 *  Created on: January 01, 2022
 *      Author: JeeGS
 */

#ifndef INC_USER_H_
#define INC_USER_H_

#include <stdio.h>
#include <math.h>

extern uint32_t loop_counter;
extern uint16_t CH1, CH2, CH3, CH4, CH5, CH6, CH7, CH8, CH9, CH10;
extern uint8_t flightMode;
extern uint8_t ARMED;
extern float battery_voltage;
extern float takeoff_heading_angle;
extern uint8_t error;
extern uint8_t heading_lock, extendedMode;
extern uint8_t battCell;

//@ESC:
extern int16_t esc1, esc2, esc3, esc4, esc5, esc6;
extern uint16_t throttle;


#endif /* INC_USER_H_ */


