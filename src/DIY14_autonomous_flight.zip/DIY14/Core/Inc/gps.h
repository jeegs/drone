/*
 * gps.h
 *
 *  Created on: Mar 27, 2022
 *      Author: gyoos
 */

#ifndef INC_GPS_H_
#define INC_GPS_H_

#include "main.h"

extern UART_HandleTypeDef huart3;
#define DMA_BUFFER_SIZE 100
#define dma_empty_buffer  huart3.hdmarx->Instance->NDTR
#define GPS_BRAKER_BUF_SIZE 35*4  //35->70

extern uint8_t usart3_rx_dma_buffer[DMA_BUFFER_SIZE];
extern float gps_pid_pitch_out;
extern float gps_pid_roll_out;

//@GPS related:
extern uint8_t gps_waypoint_cnt;
extern float dest_lat_buffer[30];
extern float dest_lon_buffer[30];
extern uint32_t dest_gps_lat;
extern uint32_t dest_gps_lon;

extern uint32_t follow_lat;
extern uint32_t follow_lon;

extern uint8_t nextWPoint;

extern int32_t gps_home_lat;
extern int32_t gps_home_lon;
extern uint8_t home_pointed;

extern uint8_t gps_enabled;

typedef struct {
	float Kp;
	float Ki;
	float Kd;
	int32_t lat_final;
	int32_t lon_final;
	uint8_t fix_type;
	uint8_t satellite;
	uint8_t speed;
	uint8_t setpointed;
	int32_t lat_setpoint;//2022-4-12:int32_t
	int32_t lon_setpoint;
	float lat_error;
	float lon_error;
	float lat_propotional;
	float lon_propotional;
	float lat_integral;
	float lon_integral;
	float lat_derivative;
	float lon_derivative;
	float prev_lat_error;
	float prev_lon_error;
} neo_M8N;
extern neo_M8N gps;

uint8_t gps_raw_read(void);
void gps_upgrade_ready(uint16_t upgrade_hz);
uint8_t gps_upgrade(uint16_t upgrade_hz);
uint8_t gps_parsing(uint8_t i, uint8_t *rx_buff);
void gps_calculation(void);
void gps_single_PID(void);
void gps_reset(void);
void waypoint(void);
void return_to_home(void);
void gps_speed(void);
void make_gps_setpoints(void);
void waypoint_navigation(int32_t destLat, int32_t destLon);
void waypoint_reset(void);
void gps_setpoint_change_apply(void);
void gps_setpoint_change_by_USER(void);
void gps_setpoint_change_by_GPS(void);
void dir_vector_calculation(int32_t destLat, int32_t destLon);
void autonomous_flight(void);
void moveto(int32_t destLat, int32_t destLon);
float* make_direction(int32_t startLat, int32_t startLon, int32_t destLat, int32_t destLon);

#endif /* INC_GPS_H_ */

