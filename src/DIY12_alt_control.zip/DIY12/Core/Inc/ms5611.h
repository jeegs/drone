/*
 * ms5611.h
 *
 *  Created on: Mar 27, 2022
 *      Author: JeeGS
 */

#ifndef INC_MS5611_H_
#define INC_MS5611_H_

extern float takeoff_pressure;
extern uint8_t takeoff_throttle_calculated;
extern uint16_t alt_user_throttle;
extern int16_t takeoff_throttle;
extern float alt_out;

typedef struct {
	float Kp;
	float Ki;
	float Kd;
	float current_pressure;
	float complementary_pressure;
	float setpoint;
	uint8_t setpointed;
	float error;
	float propotional;
	float integral;
	float derivative;
	float prev_error;
} altitude;
extern altitude baro;

void baro_init(void);
void make_baro_throttle(void);
void baro_pid_reset(void);
void baro_setpoint_change_by_USER(void);
void baro_single_PID(void);

#endif /* INC_MS5611_H_ */

