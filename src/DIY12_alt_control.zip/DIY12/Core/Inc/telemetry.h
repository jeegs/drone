/*
 * telemetry_.h
 *
 *  Created on: 2022. 3. 14.
 *      Author: JeeGS
 */

#ifndef INC_TELEMETRY_H_
#define INC_TELEMETRY_H_

#include "main.h"
#include "user.h"

extern uint32_t received_telemetry_data1;
extern uint32_t received_telemetry_data2;
extern uint8_t usart1_rx_flag;
extern uint8_t usart1_rx_data[9];
extern float telemetry_Kp, telemetry_Ki, telemetry_Kd;


void send_telemetry(uint16_t during);
void receive_telemetry(void);
void telemetry(void);

#endif /* INC_TELEMETRY_H_ */
