/*
 * pid1.h
 *
 *  Created on: 2022. 3. 12.
 *      Author: 82102
 */

#include <stdio.h>

#ifndef INC_PID_H_
#define INC_PID_H_

typedef struct {
	float Kp;
	float Ki;
	float Kd;
	float propotional;
	float integral;
	float derivative;
	float prev_error;
} PID;
extern PID roll, pitch, yaw;

float double_PID(uint8_t choice, float angle, float angular_velocity, uint16_t rc);
float restrict_max(float value, int16_t pid_max);
void gyro_pid_reset();
void pid_gain_init(uint8_t type, float kp, float ki, float kd);

#endif /* INC_PID_H_ */




