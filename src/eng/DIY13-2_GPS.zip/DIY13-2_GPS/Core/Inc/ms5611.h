/*
 * ms5611.h
 *
 *  Created on: Mar 27, 2022
 *      Author: gyoos
 */

#ifndef INC_MS5611_H_
#define INC_MS5611_H_

extern float takeoff_pressure;
extern uint8_t takeoff_throttle_calculated;

extern uint16_t alt_user_throttle;
extern int16_t takeoff_throttle;
extern float alt_out;



typedef struct {
	float Kp;
	float Ki;
	float Kd;
	float current_pressure;
	float complementary_pressure;
	float setpoint;
	uint8_t setpointed;
	float error;
	float propotional;
	float integral;
	float derivative;
	float prev_error;
} altitude;
extern altitude baro;

//extern float altitude_meter;

//void baro_reset(void);
void baro_init(void);
//void baro_pressure_request(void);
//void baro_pressure_get(void);
//void baro_temp_request(void);
//void baro_temp_get(void);
//void baro_actual_pressure(void);
void make_baro_throttle(void);
//void baro_gain(float kp, float ki, float kd);
//uint16_t baro_readProm(uint8_t);
//uint32_t baro_raw_read(void);
//void baro_breaker_making(void);
//void baro_setpoint_change_by_USER(uint16_t ch3);
void baro_pid_reset(void);
void baro_setpoint_change_by_USER(void);
void baro_single_PID(void);
//float baro_single_PID(float current_pressure, float setpoint);
//void baro_pid_calculate(void);
//void baro_height_meter(float pressure);
//void baro_complementary_pressure(int64_t p);

#endif /* INC_MS5611_H_ */

