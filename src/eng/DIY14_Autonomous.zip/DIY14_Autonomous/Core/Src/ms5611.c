/*
 * ms5611.c:
 *
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "user.h"
#include "ms5611.h"
#include "pid.h"
#include "main.h"

#include <stdlib.h>

//Localization of global variables:
altitude baro;
uint16_t alt_user_throttle;
float alt_out;

//Local variables:
uint16_t C[7];
int64_t OFF, SENS, P;
int32_t dT, dT_C5;
int32_t TEMP;
uint8_t baro_cnt, temperature_cnt;
uint8_t temp_cnt;
uint32_t D1, D2;
uint32_t temp_mem[10], temp_total;
uint8_t brake_cnt;
int32_t brake_mem[51], brake_throttle;
float prev_pressure;
float pressure_delay;
uint8_t P_cnt;
int32_t P_mem[50], P_total;
uint8_t alt_user_changed;
float baro_error_kp;

void spi2_open() {
	LL_GPIO_ResetOutputPin(GPIOB, SPI2_CS_Pin);
}

void spi2_close() {
	LL_GPIO_SetOutputPin(GPIOB, SPI2_CS_Pin);
}

uint8_t spi2_transfer(uint8_t _address) {
	while (LL_SPI_IsActiveFlag_TXE(SPI2) == RESET);
	LL_SPI_TransmitData8(SPI2, _address);
	while (LL_SPI_IsActiveFlag_RXNE(SPI2) == RESET);
	return LL_SPI_ReceiveData8(SPI2);
}


/*
 * @ data_sheet:
 1. Reset
 2. Read PROM (128 bit of calibration words)
 3. D1 conversion
 4. D2 conversion
 5. Read ADC result (24 bit pressure / temperature)
 * output: 980xx => 980.xx hpa

 * 10m -> 1.2hpa, 1m->0.12hpa, 10cm-> 0.012hpa //hpa = mbar!!! cf. our MS5611's Resolution:0.012mbar & OSR: 4096
 * JC: 1033.1hpa(sea level), Koaru_Apt: sea level 380m?
 *
 */
void baro_reset(void) {
	spi2_open();
	spi2_transfer(0x1E);
	spi2_close();
}

uint16_t baro_readProm(uint8_t i) {
	// read two bytes from SPI and return accumulated value
	uint8_t offset = i * 2;
	uint16_t val = 0;
	spi2_open();
	spi2_transfer(0xA0 + offset);                          // send command
	val = spi2_transfer(0x00) * 256;                // read 8 bits of data (MSB)
	val += spi2_transfer(0x00);                     // read 8 bits of data (LSB)
	spi2_close();
	return val;
}

void baro_init(void) {
	baro_reset();
	LL_mDelay(4);
	for (uint8_t i = 1; i <= 6; i++) {
		C[i] = baro_readProm(i);
	}
}

uint32_t baro_raw_read(void) {
	uint32_t val = 0;//UL;
	spi2_open();
	spi2_transfer(0x00);
	val = spi2_transfer(0x00) << 16 | spi2_transfer(0x00) << 8 | spi2_transfer(0x00);
	spi2_close();
	return val;
}

void baro_pressure_request(void) {
	spi2_open();
	spi2_transfer(0x48);
	spi2_close();
}
void baro_pressure_get(void) {
	D1 = baro_raw_read();
}

void baro_temp_request(void) {
	spi2_open();
	spi2_transfer(0x58);
	spi2_close();
}

void baro_temp_get(void) {
	//use 3 rotating memory to prevent temperature spikes.
	temp_total -= temp_mem[temp_cnt];
	temp_mem[temp_cnt] = baro_raw_read();
	temp_total += temp_mem[temp_cnt];
	temp_cnt++;
	if (temp_cnt == 3) {
		temp_cnt = 0;
	}
	D2 = temp_total / 3;
	//D2 = baro_raw_read();
}

int64_t  baro_raw_pressure(void) {

	uint32_t Tref, dT;
	uint32_t dTC6;
	Tref = C[5] * 256UL;
	//D2==D2:
	if (D2 < Tref) { // (to avoid signed int so we can bit-shift for divisioning)
		dT = Tref - D2;
		dTC6 = ((uint64_t) dT * (uint64_t) C[6]) >> 23;
		TEMP = 2000 - dTC6;
	} else {
		dT = D2 - Tref;
		dTC6 = ((uint64_t) dT * (uint64_t) C[6]) >> 23;
		TEMP = 2000 + dTC6;
	}

	// OFF = offT1 + TCO * dT = C2 * 2^16 + (C4 * dT ) / 2^7
	uint64_t offT1 = (uint64_t) C[2] << 16;  // OFF_C2
	uint64_t TCOdT = ((uint64_t) C[4] * (uint64_t) dT) >> 7;
	//int64_t OFF;
	if (D2 < Tref) {
		OFF = offT1 - TCOdT;
	} else {
		OFF = offT1 + TCOdT;
	}

	// SENSE = sensT1 + TCS * dT = C1 * 2^15 + (C3 * dT ) / 2^8
	uint64_t sensT1 = (uint64_t) C[1] << 15;  //SENS_C1
	uint64_t TCSdT = ((uint64_t) C[3] * (uint64_t) dT) >> 8;
	//int64_t SENS;
	if (D2 < Tref) {
		SENS = sensT1 - TCSdT;
	} else {
		SENS = sensT1 + TCSdT;
	}

	// SECOND ORDER COMPENSATION - PAGE 8/20 of the datasheet
	// COMMENT OUT < 2000 CORRECTION IF NOT NEEDED
	// NOTE TEMPERATURE IS IN 0.01 C
	uint32_t T2 = 0;
	uint32_t OFF2 = 0;
	uint32_t SENS2 = 0;
	if (TEMP < 2000) {
		uint64_t tSQ;
		T2 = ((uint64_t) dT * (uint64_t) dT) >> 31;
		tSQ = (int32_t) TEMP - 2000L;
		tSQ *= tSQ;
		OFF2 = (5ULL * (uint64_t) tSQ) >> 1;
		SENS2 = (5ULL * (uint64_t) tSQ) >> 2;
		// COMMENT OUT < -1500 CORRECTION IF NOT NEEDED
		if (TEMP < -1500) {
			tSQ = (int32_t) TEMP - 2000L;
			tSQ *= tSQ;
			OFF2 += 7ULL * (uint64_t) tSQ;
			SENS2 += (11ULL * (uint64_t) tSQ) >> 1;
		}
	}

	TEMP -= T2;
	OFF -= OFF2;
	SENS -= SENS2;
	//
	// END SECOND ORDER COMPENSATION
	//

	int64_t P = (int64_t) D1 * SENS;	  //D1:D1
	P /= 2097152LL;
	P -= OFF;
	P /= 32768LL;

	return P;
}

void baro_complemented_pressure(int64_t raw_pressure) {
	//To get a smoother pressure value, we will use a 20 location rotating memory.
	P_total -= P_mem[P_cnt];
	P_mem[P_cnt] = raw_pressure;
	P_total += P_mem[P_cnt];
	P_cnt++;
	if (P_cnt == 40) {
		P_cnt = 0;
	}
	baro.current_pressure = (float) P_total / 40.0;
	baro.complementary_pressure = baro.complementary_pressure * (float) 0.98 + baro.current_pressure * (float) 0.02;
	//@ 출렁임을 억제하기 위해 썼던 일들에 의한 늘어짐(지연) 방지: max 1.0
	//늘어짐(지연)은 제어가 느리다는 뜻
	pressure_delay = baro.complementary_pressure - baro.current_pressure;
	if (pressure_delay > 5)
		pressure_delay = 5;
	if (pressure_delay < -5)
		pressure_delay = -5;
	if (pressure_delay > 1 || pressure_delay < -1)//abs(pressure_delay) > 1
		baro.complementary_pressure -= pressure_delay / 5.0;
}

int16_t make_altitude(float complementary_pressure) {
	/*H_temp = complementary_pressure / 101325;
	H_alt = (1 - pow(H_temp, 0.190284)) * 145366.45;
	Altitude = 0.3048 * H_alt;
	*/
	return 0;
}


void baro_pid_calculate(void) {

	brake_throttle -= brake_mem[brake_cnt];
	brake_mem[brake_cnt] = baro.complementary_pressure * 10 - prev_pressure;
	if (alt_user_changed == 1) brake_mem[brake_cnt] = 0;
	brake_throttle += brake_mem[brake_cnt];
	prev_pressure = baro.complementary_pressure * 10;
	brake_cnt++;
	if (brake_cnt == 30) {
		brake_cnt = 0;
	}

	if (flightMode >= 2 && baro.setpointed == 0) {
		baro.setpointed = 1;
		baro.setpoint = baro.complementary_pressure;
	}
	if (flightMode >= 2 && baro.setpointed == 1) {
		baro_setpoint_change_by_USER();
		baro_single_PID();
	}
	if (flightMode < 2 && baro.setpointed == 1) {//2022-05-15
		baro_pid_reset();
	}
}

void baro_setpoint_change_by_USER(void)
{
	if (CH3 > (1600 - takeoff_throttle)) {// throttle = 1500 - takeoff_throttle;
		alt_user_throttle = (CH3 - (1600 - takeoff_throttle)) / 3;
		baro.setpoint = baro.complementary_pressure;
		alt_user_changed = 1;
	} else  if (CH3 < (1400 - takeoff_throttle)) {
		alt_user_throttle = (CH3 - (1400 - takeoff_throttle)) / 5;
		baro.setpoint = baro.complementary_pressure;
		alt_user_changed = 1;
	} else {
		alt_user_throttle = 0;
		alt_user_changed = 0;
	}
}

void baro_single_PID(void) {
	baro.error = baro.complementary_pressure - baro.setpoint;
	//(BARO_GAIN, 1.5, 0.0005, 1.0):
	baro.propotional = baro.Kp * baro.error;
	baro.integral += baro.Ki * baro.error;
	baro.integral = restrict_max(baro.integral, 300);
	baro.derivative = baro.Kd * brake_throttle;
	baro.prev_error = baro.error;
	alt_out = baro.propotional + baro.integral + baro.derivative;
	alt_out = restrict_max(alt_out, 300);
}

void baro_pid_reset(void) {
	baro.setpointed = 0;//2022-05-15
	baro.integral = 0;
	baro.prev_error = 0;
	alt_out = 0;
	alt_user_throttle = 0;
	takeoff_throttle_calculated = 0;
	alt_user_changed = 1;
}

void make_baro_throttle(void) {
	if (loop_counter % 9 == 0) {
		if (temperature_cnt++ == 0)
			baro_temp_get();
		else {
			baro_pressure_get();
		}
		if (temperature_cnt == 40) {//20
			temperature_cnt = 0;
			baro_temp_request();
		} else {
			baro_pressure_request();
		}
		int64_t final_pressure = baro_raw_pressure();
		baro_complemented_pressure(final_pressure);
		baro_pid_calculate();
	}
}
