/*
2021_11_18 revised:
2021-12-22 revised: nose direction when way points move.
2022-05-20 fine:
 */

package com.copter1.new20;

import static android.graphics.Bitmap.Config.ARGB_8888;
import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import tech.gusavila92.websocketclient.WebSocketClient;//private:
import android.os.Handler;
import android.widget.Toast;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback, ActivityCompat.OnRequestPermissionsResultCallback
{
    public LocationManager locationManager;
    public Location location;

    MediaPlayer tuk_sound, clear_sound, no_sound;
    private GoogleMap mGoogleMap = null;
    private Marker currentMarker = null;

    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private static final int UPDATE_INTERVAL_MS = 100;
    private static final int FASTEST_UPDATE_INTERVAL_MS = 250; //<--- 500 ( )
    private static final int PERMISSIONS_REQUEST_CODE = 100;
    boolean needRequest = false;
    String[] REQUIRED_PERMISSIONS = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest locationRequest;

    private WebSocketClient webSocketClient;
    Boolean esp_connected;
    String total_str;
    String[] str_array;

    TextView errorTV, batteryTV;
    TextView satelliteTV, speedTV, altitudeTV, flight_modeTV, gps_WPointTV;
    TextView p_gainTV, i_gainTV, d_gainTV;
    TextView telemetryTV, timeTV;

    float p_gain, i_gain, d_gain;
    Button clearBtn;
    Boolean flightTimeEnable;
    int flight_time;
    Boolean only_once;

    String gainChange = "Gain change";
    String CH1 = "CH1";
    String CH2 = "CH2";
    String CH3 = "CH3";
    String CH4 = "CH4";
    String CH5 = "CH5";
    String CH6 = "CH6";
    String CH7 = "CH7";
    String CH8 = "CH8";
    String socketOn = "socketOn";
    String socketErr = "socketErr";

    String RC = "RC";
    String ALT = "ALT";
    String GPSHOLD = "GPSHold";
    String RTH = "RTH";
    String WAYPoint = "WAYPoint";
    String Circle = "Circle";
    String FollowMe = "FollowMe";

    String OK = "YES";
    String NO = "NO";

    String GPS_error = "No GPS!";

    int map_click_cnt;
    double fc_gps_lat, fc_gps_lon; //----> 4byte
    double phone_gps_lat, phone_gps_lon;
    String fc_lat_str, fc_lon_str;
    LatLng currentLatLng;
    double radian_distance;
    private ArrayList<String> returned_lat, returned_lon;

    MarkerOptions markerOptions;
    Bitmap dotMarker;
    double point_latitude;
    double point_longitude;
    String pointed_lat_str, pointed_lon_str;
    String phone_lat_str, phone_lon_str;

    double lat_distance, lon_distance, gps_distance;
    Polyline line;
    private PolylineOptions polylineOptions;
    private ArrayList<LatLng> arrayPoints;
    short quad_angle = 0;
    short flightMode = 1;
    int extended;
    short gps_waypoint_cnt;
    short gps_nextWPoint;
    short battCell;
    short battery_low_count;
    float batt;
    int ARMED;
    float alt;

    Bitmap bm;
    Handler handler;
    short returned_lat_size;
    short returned_lon_size;
    RadioGroup radioGroup;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        createWebSocketClient();

        errorTV = findViewById(R.id.error);
        batteryTV = findViewById(R.id.battery);
        satelliteTV = findViewById(R.id.satellite);
        speedTV = findViewById(R.id.speed);
        altitudeTV = findViewById(R.id.altitude);
        flight_modeTV = findViewById(R.id.flight_mode);
        p_gainTV = findViewById(R.id.p_gain);
        i_gainTV = findViewById(R.id.i_gain);
        d_gainTV = findViewById(R.id.d_gain);
        telemetryTV = findViewById(R.id.telemetry);
        timeTV = findViewById(R.id.time);
        gps_WPointTV = findViewById(R.id.waypoints);

        clearBtn = findViewById(R.id.clr_Btn);
        radioGroup = findViewById(R.id.radio_group);

        //@vars initialize:
        flightTimeEnable = false;
        flight_time = 0;
        only_once = false;
        map_click_cnt = 0;
        battery_low_count = 0;
        fc_gps_lat = 0;
        fc_gps_lon = 0;
        fc_lat_str = "0";
        fc_lon_str = "0";
        pointed_lat_str = "1";
        pointed_lon_str = "1";

        returned_lat = new ArrayList<>();
        returned_lon = new ArrayList<>();
        arrayPoints = new ArrayList<>();

        tuk_sound = MediaPlayer.create(MainActivity.this, R.raw.tuk);
        clear_sound = MediaPlayer.create(MainActivity.this, R.raw.delete);
        no_sound = MediaPlayer.create(MainActivity.this, R.raw.no);

        markerOptions = new MarkerOptions();
        BitmapDrawable bitmapdraw = (BitmapDrawable) ResourcesCompat.getDrawable(getResources(), R.drawable.pot, null);
        if (bitmapdraw.getBitmap() != null) {
            bm = bitmapdraw.getBitmap();
            dotMarker = Bitmap.createScaledBitmap(bm, 25, 25, false);
        }

        locationRequest = new LocationRequest()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL_MS)
                .setFastestInterval(FASTEST_UPDATE_INTERVAL_MS);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(locationRequest);
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                webSocketClient.send("99,99");
                mGoogleMap.clear();
                arrayPoints.clear();//lines:
                pointed_lat_str = "1";
                pointed_lon_str = "1";
                only_once = false;
                map_click_cnt = 0;
            }
        });

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 1, gpsLocationListener);

        handler = new Handler();
        handler.post(runnableCode);


    }

    final LocationListener gpsLocationListener = new LocationListener() {
        public void onLocationChanged(Location location) {
            phone_gps_lat = location.getLatitude();
            phone_gps_lon = location.getLongitude();
            //double altitude = location.getAltitude();
            if(flightMode == 5) {
                if (phone_gps_lat > 0 && phone_gps_lon > 0) {
                    String phone_lat_temp = Double.toString(phone_gps_lat);
                    String phone_lon_temp = Double.toString(phone_gps_lon);
                    phone_lat_str = phone_lat_temp.substring(0, 2) + phone_lat_temp.substring(3, 9);//37.123456 =>37123456
                    phone_lon_str = phone_lon_temp.substring(0, 3) + phone_lon_temp.substring(4, 10);//128.123456 =>128123456
                    webSocketClient.send(phone_lat_str + "," + phone_lon_str);
                }
            }
        } public void onStatusChanged(String provider, int status, Bundle extras) { } public void onProviderEnabled(String provider) { } public void onProviderDisabled(String provider) { }
    };

    private final Runnable runnableCode = new Runnable() {
        @Override
        public void run() {
            if (flightTimeEnable) {
                flight_time += 2;
                timeTV.setText(String.valueOf(flight_time));
                timeTV.append("초");
            }
            if (battery_low_count > 25) {//200ms(50*2*2) * 15 = 3s, 2021-12-12
                battery_low_count = 0;
            }
            handler.postDelayed(runnableCode, 2000);
        }
    };

     //websocket:
    private void createWebSocketClient() {
        URI uri;
        try {
            uri = new URI("ws://192.168.xx.xx:80/");//Websocket server IP from esp32:
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return;
        }
        webSocketClient = new WebSocketClient(uri) {
            @Override
            public void onOpen() {
                esp_connected = true;
            }

            @Override
            public void onTextReceived(String message) {
                total_str = message;
                runOnUiThread(new Runnable() {
                    public void run() {
                        str_array = total_str.split(",");
                        for (int i = 0; i < str_array.length; i++) {
                            if (i == 0) {
                                switch (str_array[i]) {
                                    case "0":
                                        errorTV.setText("Not Yet");
                                        errorTV.setTextColor(Color.parseColor("#1064ea"));
                                        break;
                                    case "1":
                                        errorTV.setText("Gyro");
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "2":
                                        errorTV.setText("Low Volt");
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "3":
                                        errorTV.setText(CH8);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "4":
                                        errorTV.setText(CH7);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "5":
                                        errorTV.setText(CH6);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "6":
                                        errorTV.setText(CH5);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "7":
                                        errorTV.setText(CH4);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "8":
                                        errorTV.setText(CH3);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "9":
                                        errorTV.setText(CH2);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "10":
                                        errorTV.setText(CH1);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "11":
                                        errorTV.setText("Barometer");
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "12":
                                        errorTV.setText("Satellite");
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "13":
                                        errorTV.setText("Magnetometer");
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "40":

                                        break;
                                    case "41":

                                        break;
                                    case "42":

                                        break;
                                    case "43":

                                        break;
                                    case "44":

                                        break;
                                    case "46":

                                        break;
                                    case "47":

                                    case "70":
                                        errorTV.setText(GPS_error);
                                        errorTV.setTextColor(Color.parseColor("#ea3f10"));
                                        break;
                                    case "100":
                                        errorTV.setText(gainChange);
                                        errorTV.setTextColor(Color.parseColor("#1064ea"));
                                        break;
                                    case "socketOn":
                                        errorTV.setText(socketOn);
                                        errorTV.setTextColor(Color.parseColor("#aa80ff"));
                                        break;

                                    default:
                                        errorTV.setText(socketErr);
                                        errorTV.setTextColor(Color.parseColor("#aa80ff"));
                                }
                            } else if (i == 1) {
                                batt = Float.parseFloat(str_array[i]) / 100;
                                batteryTV.setText(String.valueOf(batt));
                            } else if (i == 2) {
                                fc_lat_str = str_array[i];
                            } else if (i == 3) {
                                fc_lon_str = str_array[i];
                            } else if (i == 4) {// //dest_gps_latTV[11]
                                if (str_array[i].equals(pointed_lat_str)) {//37134716:
                                    pointed_lat_str = "";//for one comparison:
                                    returned_lat.add(str_array[i]);
                                    returned_lat_size = (short) returned_lat.size();
                                }
                            } else if (i == 5) {//dest_gps_lonTV[12]
                                if (str_array[i].equals(pointed_lon_str)) {
                                    pointed_lon_str = "";
                                    returned_lon.add(str_array[i]);//Not pointed_array, But returned_array:
                                    returned_lon_size = (short) returned_lon.size();
                                    tuk_sound.start();
                                }
                            } else if (i == 6) {
                                satelliteTV.setText(str_array[i]);
                                if (Integer.parseInt(str_array[i]) >= 7) {
                                    satelliteTV.setTextColor(Color.parseColor("#1064ea"));
                                } else {
                                    satelliteTV.setTextColor(Color.parseColor("#919194"));
                                }
                            } else if (i == 7) {
                                speedTV.setText(str_array[i]);
                            } else if (i == 8) {//altitudeTV:
                                alt = Float.parseFloat(str_array[i]);
                                if(alt < 50000) {
                                    alt *= 0.1;
                                    altitudeTV.setText(String.valueOf(alt));
                                    altitudeTV.append("m");
                                } else altitudeTV.setText(String.valueOf(alt));
                            } else if (i == 9) {//flightModeTV:
                                //getLeast:
                                int tmp = Integer.parseInt(str_array[i]);
                                int fm = tmp & 0x0F;
                                //getMost:
                                ARMED = (tmp & 0xF0) >> 4;
                                switch (fm) {
                                    case 0:
                                        flight_modeTV.setText("*");
                                        break;
                                    case 1://10 0001
                                        flightMode = 1;
                                        flight_modeTV.setText(RC);
                                        break;
                                    case 2://10 0010
                                        flightMode = 2;
                                        flight_modeTV.setText(ALT);
                                        break;
                                    case 3:
                                        flightMode = 3;
                                        flight_modeTV.setText(GPSHOLD);
                                        break;
                                    case 4:
                                        flightMode = 4;
                                        flight_modeTV.setText(RTH);
                                        break;
                                    case 5:
                                        flightMode = 5;
                                        flight_modeTV.setText(FollowMe);
                                        break;
                                    case 6:
                                        flightMode = 6;
                                        flight_modeTV.setText(Circle);
                                        break;
                                    case 7:
                                        flightMode = 7;
                                        flight_modeTV.setText(WAYPoint);
                                        break;
                                }
                            } else if (i == 10) {
                                gps_nextWPoint = Short.parseShort(str_array[i]);
                            } else if (i == 11) {
                                extended = Integer.parseInt(str_array[i]);
                                switch (extended) {
                                    case 0:
                                        radioGroup.check(R.id.basicRB);
                                        break;
                                    case 1:
                                        radioGroup.check(R.id.hlRB);
                                        break;
                                    case 2:
                                        radioGroup.check(R.id.circleRB);
                                        break;
                                    case 3:
                                        radioGroup.check(R.id.wpRB);
                                        break;
                                    default:
                                }
                            } else if (i == 12) {
                                p_gain = Float.parseFloat(str_array[i]) / 10;
                                p_gainTV.setText(String.valueOf(p_gain));
                            } else if (i == 13) {
                                i_gain = Float.parseFloat(str_array[i]) / 1000000;
                                i_gainTV.setText(String.valueOf(i_gain));
                            } else if (i == 14) {
                                d_gain = Float.parseFloat(str_array[i]) / 10;
                                d_gainTV.setText(String.valueOf(d_gain));
                            } else if (i == 15) {
                                gps_waypoint_cnt = Short.parseShort(str_array[i]);//gps_waypoint_cnt--;
                                if (gps_waypoint_cnt == 0) {
                                    returned_lat.clear();
                                    returned_lon.clear();
                                    gps_WPointTV.setText("0");
                                    //tuk_sound.start();
                                }
                                else if (returned_lat_size == gps_waypoint_cnt && returned_lon_size == gps_waypoint_cnt) {
                                    //if(gps_waypoint_cnt != 0) Toast.makeText(MainActivity.this, "OK", Toast.LENGTH_LONG).show();
                                    gps_WPointTV.setText(String.valueOf(gps_waypoint_cnt));
                                }
                            } else if (i == 16) {
                                if (ARMED == 2) flightTimeEnable = true;
                                else flightTimeEnable = false;

                                battCell = Short.parseShort(str_array[i]);//gps_waypoint_cnt--;
                                telemetryTV.setText(OK);
                                telemetryTV.setTextColor(Color.parseColor("#1064ea"));
                                if (battCell == 3) {
                                    if (batt > 10.50) {//3s(12.6V->10.50), 4s(16.8V->14.0)
                                        batteryTV.setTextColor(Color.parseColor("#1064ea"));
                                        no_sound.start();
                                    } else {
                                        batteryTV.setTextColor(Color.parseColor("#919194"));
                                        battery_low_count++;
                                    }
                                }
                                if (battCell == 4) {
                                    if (batt > 14.00) {
                                        batteryTV.setTextColor(Color.parseColor("#1064ea"));
                                        no_sound.start();
                                    } else {
                                        batteryTV.setTextColor(Color.parseColor("#919194"));
                                        battery_low_count++;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            @Override
            public void onBinaryReceived(byte[] data) {
                System.out.println("onBinaryReceived");
            }

            @Override
            public void onPingReceived(byte[] data) {
                System.out.println("onPingReceived");
            }

            @Override
            public void onPongReceived(byte[] data) {
                System.out.println("onPongReceived");
            }

            @Override
            public void onException(Exception e) {
                //System.out.println(e.getMessage());
                telemetryTV.setTextColor(Color.parseColor("#aa80ff"));
                telemetryTV.setText(NO);
            }

            @Override
            public void onCloseReceived() {
                System.out.println("onCloseReceived");
            }
        };
        webSocketClient.setConnectTimeout(2000);//1000:(6,3)-> good
        webSocketClient.setReadTimeout(2000);
        webSocketClient.enableAutomaticReconnection(2000);
        webSocketClient.connect();
    }
    //websocket ---------------------------------------> end

    LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            fc_gps_lat = Double.parseDouble(fc_lat_str);
            fc_gps_lon = Double.parseDouble(fc_lon_str);
            fc_gps_lat /= 1000000.0;
            fc_gps_lon /= 1000000.0;

            if (currentMarker != null) currentMarker.remove();

            currentLatLng = new LatLng(fc_gps_lat, fc_gps_lon);
            markerOptions.position(currentLatLng);
            markerOptions.title("fc");
            markerOptions.icon(BitmapDescriptorFactory.fromBitmap(dotMarker));
            currentMarker = mGoogleMap.addMarker(markerOptions);
            // focus on and animate the camera to the drone:
            /*CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(currentLatLng)
                    .zoom(19)
                    .bearing(0)
                    .tilt(0)
                    .build();
            mGoogleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));*/
            mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 19));//20
            //System.out.println("'fc_latitude' String ---------->" + fc_gps_lat);//37.134716
            //System.out.println("fc_longitude' String ---------->" + fc_gps_lon);//128.198855
        }
    };

    private void startLocationUpdates() {


        if (!checkLocationServicesStatus()) {
            //Log.d(TAG, "startLocationUpdates : call showDialogForLocationServiceSetting");
            showDialogForLocationServiceSetting();
        } else {
            int hasFineLocationPermission = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION);
            int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION);

            if (hasFineLocationPermission != PackageManager.PERMISSION_GRANTED ||
                    hasCoarseLocationPermission != PackageManager.PERMISSION_GRANTED) {
                //Log.d(TAG, "startLocationUpdates : No permition.");
                return;
            }
            //Log.d(TAG, "startLocationUpdates : call mFusedLocationClient.requestLocationUpdates");
            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

            if (checkPermission())
                mGoogleMap.setMyLocationEnabled(true);
        }
    }

    public Bitmap makeBitmap(Context context, String text)
    {
        Resources resources = context.getResources();
        float scale = resources.getDisplayMetrics().density;
        Bitmap bitmap = BitmapFactory.decodeResource(resources, R.drawable.p2);
        bitmap = bitmap.copy(ARGB_8888, true);

        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setTextSize(15 * scale);
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);

        int x = bitmap.getWidth() - bounds.width() - 30;
        int y = bounds.height() + 18;
        //Toast.makeText(MainActivity.this,text, Toast.LENGTH_SHORT).show();
        if(text.length() == 2) x = bitmap.getWidth() - bounds.width() - 25;
        if(text.equals("1")) x = bitmap.getWidth() - bounds.width() - 36;
        canvas.drawText(text, x, y, paint);

        return  bitmap;
    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {
        mGoogleMap = googleMap;

        int hasFineLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION);
        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED && hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {

            startLocationUpdates();

        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])) {
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        }
        mGoogleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            public void onMapClick(LatLng point) {

                if(extended == 3) {
                    map_click_cnt++;
                    point_latitude = point.latitude;
                    point_longitude = point.longitude;

                    Bitmap bitmap = makeBitmap(MainActivity.this, map_click_cnt + "");
                    MarkerOptions markerOptions = new MarkerOptions()
                            .position(new LatLng(point_latitude, point_longitude))
                            .icon(BitmapDescriptorFactory.fromBitmap(bitmap));
                    mGoogleMap.addMarker(markerOptions);

                    //@2021-12-15:
                    lat_distance = Math.abs(fc_gps_lat - point_latitude);//double
                    lon_distance = Math.abs(fc_gps_lon - point_longitude);

                    gps_distance = Math.sqrt((lat_distance * lat_distance) + (lon_distance * lon_distance));
                    gps_distance = (int) (gps_distance * 100000);//m
                    Toast.makeText(MainActivity.this, gps_distance + "m", Toast.LENGTH_SHORT).show();
                    // 1) ----------------------------------------------------------------> start
                    if (!only_once) {
                        line = mGoogleMap.addPolyline(new PolylineOptions()
                                .add(new LatLng(fc_gps_lat, fc_gps_lon), new LatLng(point_latitude, point_longitude))
                                .width(2)
                                .color(Color.RED));
                        only_once = true;

                        quad_angle = bearingP1toP2(fc_gps_lat, fc_gps_lon, point_latitude, point_longitude);
                    } else {
                        line = mGoogleMap.addPolyline(new PolylineOptions()
                                .add(new LatLng(fc_gps_lat, fc_gps_lon), new LatLng(point_latitude, point_longitude))
                                .width(1)
                                .color(Color.GRAY));
                    }
                    // 1) ----------------------------------------------------------------> end
                    // 2) ------------------------------------> start
                    polylineOptions = new PolylineOptions();
                    polylineOptions.color(Color.RED);
                    polylineOptions.width(2);
                    arrayPoints.add(point);
                    polylineOptions.addAll(arrayPoints);
                    mGoogleMap.addPolyline(polylineOptions);
                    // 2) ------------------------------------> end

                    String lat_Temp = Double.toString(point_latitude);
                    String lon_Temp = Double.toString(point_longitude);
                    pointed_lat_str = lat_Temp.substring(0, 2) + lat_Temp.substring(3, 9);//37.123456 =>37123456
                    pointed_lon_str = lon_Temp.substring(0, 3) + lon_Temp.substring(4, 10);//128.123456 =>128123456
                    //System.out.println("'point_langitude' String ---------->" + pointed_lat_str);//37134716
                    //System.out.println("'point_longitude' String ---------->" + pointed_lon_str);//128198855
                    webSocketClient.send(pointed_lat_str + "," + pointed_lon_str);
                }
            }
        });
    }

    public short bearingP1toP2(double P1_latitude, double P1_longitude, double P2_latitude, double P2_longitude) {
        double Cur_Lat_radian = P1_latitude * (3.141592 / 180);
        double Cur_Lon_radian = P1_longitude * (3.141592 / 180);

        double Dest_Lat_radian = P2_latitude * (3.141592 / 180);
        double Dest_Lon_radian = P2_longitude * (3.141592 / 180);

        // radian distance
        radian_distance = 0;
        radian_distance = Math.acos(Math.sin(Cur_Lat_radian) * Math.sin(Dest_Lat_radian) + Math.cos(Cur_Lat_radian) * Math.cos(Dest_Lat_radian) * Math.cos(Cur_Lon_radian - Dest_Lon_radian));

        double radian_bearing = Math.acos((Math.sin(Dest_Lat_radian) - Math.sin(Cur_Lat_radian) * Math.cos(radian_distance)) / (Math.cos(Cur_Lat_radian) * Math.sin(radian_distance)));        // acos의 인수로 주어지는 x는 360분법의 각도가 아닌 radian(호도)값이다.

        double true_bearing;
        if (Math.sin(Dest_Lon_radian - Cur_Lon_radian) < 0) {
            true_bearing = radian_bearing * (180 / 3.141592);
            true_bearing = 360 - true_bearing;
        } else {
            true_bearing = radian_bearing * (180 / 3.141592);
        }

        return (short) true_bearing;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (checkPermission()) {
            mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
            if (mGoogleMap != null)
                mGoogleMap.setMyLocationEnabled(true);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mFusedLocationClient != null) {
            //Log.d(TAG, "onStop : call stopLocationUpdates");
            mFusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }

    public boolean checkLocationServicesStatus() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    private boolean checkPermission() {
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION);
        return (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED && hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    public void onRequestPermissionsResult(int permsRequestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grandResults) {
        if (permsRequestCode == PERMISSIONS_REQUEST_CODE && grandResults.length == REQUIRED_PERMISSIONS.length) {
            boolean check_result = true;
            for (int result : grandResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    check_result = false;
                    break;
                }
            }
            if (check_result) {
                startLocationUpdates();
            } else {
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])
                        || ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[1])) {
                    System.out.println("No permition.");
                } else {
                    System.out.println("No permition.");
                }
            }
        }
    }

    private void showDialogForLocationServiceSetting() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("No Positon setup.");
        builder.setMessage("We need position service in your phone.");
        builder.setCancelable(true);
        builder.setPositiveButton("Setup", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent callGPSSettingIntent
                        = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }
}