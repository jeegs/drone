/*
 * imu.h
 *
 *  Created on: 2021. 9. 21.
 *      Author: JeeGS
 */

#ifndef INC_IMU_H_
#define INC_IMU_H_

#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#define DPS      131.0 //+-250
#define DPS        65.5 //+-500
//#define DPS           32.8 //+-1000
//#define DPS        16.4 //+-2000

#define PWR_MGMT_1               0x6B
#define SIGNAL_PATH_RESET   0x68
#define PWR_MGMT_2               0x6C
#define CONFIG                         0x1A
#define GYRO_CONFIG              0x1B
#define ACCEL_CONFIG            0x1C
#define ACCEL_CONFIG2          0x1D
#define SMPLRT_DIV                 0x19
#define ACCEL_XOUT_H            0x3B

typedef struct {
	int16_t x;
	int16_t y;
	int16_t z;
} imuRaw;
extern imuRaw accRaw;
extern imuRaw gyroRaw;

typedef struct {
	float x;
	float y;
	float z;
} imuAngle;
extern imuAngle accAngle;
extern imuAngle gyroAngle;
extern imuAngle angleSpeed;

void spi1_open();
void spi1_close(void);
void spi1_write(uint8_t address, uint8_t val);
uint8_t spi1_transfer(uint8_t _address_or_value);
uint8_t spi1_read(uint8_t address);
void spi1_read_some(uint8_t address, uint8_t length, uint8_t *data);
void icm20602_setup(void);
void imu_read(void);
void calculate_gyro_offset(void);
void calculate_acc_offset(void);
void gyro_xyz_angular_velocity(void);
void gyro_xyz_angle(void);
void accel_xy_angle(void);
void yaw_correction(void);
void gyro_xyz_drift_correction(void);
float angle_deviation(float current_yaw, float takeoff_yaw);
#endif /* INC_IMU_H_ */
