/*
 * user.h
 *
 *  Created on: January 01, 2022
 *      Author: JeeGS
 */

#ifndef INC_USER_H_
#define INC_USER_H_

#include <stdio.h>
#include <math.h>

extern uint32_t loop_counter;

#endif /* INC_USER_H_ */


