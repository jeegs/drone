/*
 * pid.c:
 *
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "pid.h"
#include "user.h"
#include "ms5611.h"

//Localization of global variables:
 PID roll, pitch, yaw;

//Local variables:
 float pid_setpoint;
 float pid_error;
 float pid_out;

void gyro_pid_reset() {
	roll.integral = 0;
	pitch.integral = 0;
	yaw.integral = 0;
	roll.prev_error = 0;
	pitch.prev_error = 0;
	yaw.prev_error = 0;
}

void pid_gain_init(uint8_t type, float kp, float ki, float kd) {
	if (type == 1 || type == 2) {
		roll.Kp = pitch.Kp = kp;
		roll.Ki = pitch.Ki = ki;
		roll.Kd = pitch.Kd = kd;
	}
	if (type == 3) {
		yaw.Kp = kp;
		yaw.Ki = ki;
		yaw.Kd = kd;
	}
	if (type == 4) {
		baro.Kp = kp;
		baro.Ki = ki;
		baro.Kd = kd;
	}
	if (type == 5) {
	}
}

float restrict_max(float value, int16_t pid_max) {
	if (value > pid_max) 	value = pid_max;
	else if (value < pid_max * -1) value = pid_max * -1;
	return value;
}

float double_PID(uint8_t choice, float angle, float angular_velocity, uint16_t rc) {
	pid_setpoint = 0;
	if (choice == 3) {//single PID:
		if (CH3 > 1100) {
			if (rc > 1503) pid_setpoint = rc - 1503;
			else if (rc < 1497) pid_setpoint = rc - 1497;
		}
	} else {//double PID:
		if (rc > 1503) pid_setpoint = rc - 1503;
		else if (rc < 1497) 	pid_setpoint = rc - 1497;
		pid_setpoint -= angle * 17;//15->17 2022-01-06
	}
	pid_setpoint /= 2.5;
	pid_error = pid_setpoint - angular_velocity;//((497 - (29.2도*17)) / 2.5) - 현재값(각속도)

	if (choice == 1) {
		roll.propotional = roll.Kp * pid_error;
		roll.integral += roll.Ki * pid_error;
		roll.integral = restrict_max(roll.integral, 400);
		roll.derivative = roll.Kd * (pid_error - roll.prev_error);
		pid_out = roll.propotional + roll.integral + roll.derivative;
		roll.prev_error = pid_error;
	}
	if (choice == 2) {
		pitch.propotional = pitch.Kp * pid_error;
		pitch.integral += pitch.Ki * pid_error;
		pitch.integral = restrict_max(pitch.integral, 400);
		pitch.derivative = pitch.Kd * (pid_error - pitch.prev_error);
		pid_out = pitch.propotional + pitch.integral  + pitch.derivative;
		pitch.prev_error = pid_error;
	}
	if (choice == 3) {
		yaw.propotional = yaw.Kp * pid_error;
		yaw.integral += yaw.Ki * pid_error;
		yaw.integral = restrict_max(yaw.integral, 400);
		yaw.derivative = yaw.Kd * (pid_error - yaw.prev_error);
		pid_out = yaw.propotional + yaw.integral + yaw.derivative;
		yaw.prev_error = pid_error;
	}
	return restrict_max(pid_out, 400);
}
