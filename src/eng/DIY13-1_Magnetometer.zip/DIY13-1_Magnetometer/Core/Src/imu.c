/*
 * imu.c:
 *
 * Contributed by JeeGS @ Jeesaemz Book, July, 2022
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
 * DAMAGE.
 */

#include "main.h"
#include "imu.h"
#include "hmc5983.h"

//Localization of global variables:
 imuRaw accRaw;
 imuRaw gyroRaw;
 imuAngle accAngle;
 imuAngle gyroAngle;
 imuAngle angleSpeed;

//Local variables:
uint8_t gyro_offset_calculated;
uint8_t acc_offset_calculated;
int16_t acc_x_offset, acc_y_offset;
int32_t gyro_x_offset, gyro_y_offset, gyro_z_offset;
int32_t Acc_total;

void spi1_open() {
	LL_GPIO_ResetOutputPin(GPIOA, SPI1_CS_Pin);
}

void spi1_close() {
	LL_GPIO_SetOutputPin(GPIOA, SPI1_CS_Pin);
}

uint8_t spi1_transfer(uint8_t _address_or_value) {
	while (!LL_SPI_IsActiveFlag_TXE(SPI1)) {}
	LL_SPI_TransmitData8(SPI1, _address_or_value); //When TXE
	while (!LL_SPI_IsActiveFlag_RXNE(SPI1)) {}
	return LL_SPI_ReceiveData8(SPI1); //When RXNE
}

void spi1_write(uint8_t address, uint8_t val) {
	spi1_open();
	spi1_transfer(address | 0x00); //127
	spi1_transfer(val);
	spi1_close();
}

uint8_t spi1_read(uint8_t address) {
	uint8_t val;
	spi1_open();
	spi1_transfer(address | 0x80); //0x80 = 128(10) = 1000 0000(2)
	val = spi1_transfer(0x00);
	spi1_close();
	return val;
}

void spi1_read_some(uint8_t address, uint8_t length, uint8_t *data) {
	uint8_t i = 0;
	spi1_open();
	spi1_transfer(address | 0x80);
	while (i < length) {
		data[i++] = spi1_transfer(0x00);
	}
	spi1_close();
}

void icm20602_setup(void) {

	spi1_write(PWR_MGMT_1, 0x80);
	LL_mDelay(100);
	spi1_write(SIGNAL_PATH_RESET, 0x03); //ACCEL&TEMP_RST
	LL_mDelay(100);
	spi1_write(PWR_MGMT_1, 0x01); // PLL circuit enabled.
	LL_mDelay(10);
	spi1_write(PWR_MGMT_2, 0x00);
	LL_mDelay(10);
	spi1_write(CONFIG, 0x03); //=>DLPF(~43Hz)
	LL_mDelay(10);

	/*
	 #define _250DPS      131.0
	 #define _500DPS        65.5
	 #define _1000DPS      32.8
	 #define _200DPS        16.4
	 //0x00, 0x08, 0x10, 0x18
	 */
	if(DPS  == 131.0) spi1_write(GYRO_CONFIG, 0x00); //=>±250dps
	else if(DPS == 65.5) spi1_write(GYRO_CONFIG, 0x08); //=>±500dps
	else if(DPS == 32.8) spi1_write(GYRO_CONFIG, 0x10); //=>±1000dps
	else if(DPS == 16.4) spi1_write(GYRO_CONFIG, 0x18); //=>±2000dps

	LL_mDelay(10);
	spi1_write(ACCEL_CONFIG, 0x10); //=>±8g
	LL_mDelay(10);
	spi1_write(ACCEL_CONFIG2, 0x03);
	LL_mDelay(10);
	spi1_write(SMPLRT_DIV, 0x00);
}

uint8_t rawData[14];
void imu_read(void) {
	spi1_read_some(ACCEL_XOUT_H, 14, rawData);
	accRaw.y = ((int16_t) rawData[0] << 8) | rawData[1];
	accRaw.x = ((int16_t) rawData[2] << 8) | rawData[3];
	accRaw.z = ((int16_t) rawData[4] << 8) | rawData[5];
	gyroRaw.x = ((int16_t) rawData[8] << 8) | rawData[9];
	gyroRaw.y = ((int16_t) rawData[10] << 8) | rawData[11];
	gyroRaw.z = ((int16_t) rawData[12] << 8) | rawData[13];
	gyroRaw.y *= -1;
	gyroRaw.z *= -1;

	if (gyro_offset_calculated) {
		gyroRaw.x -= gyro_x_offset;
		gyroRaw.y -= gyro_y_offset;
		gyroRaw.z -= gyro_z_offset;
	}
	if (acc_offset_calculated) {
		accRaw.x -= acc_x_offset;
		accRaw.y -= acc_y_offset;
	}
}


void calculate_gyro_offset(void) {
	gyro_x_offset = 0;
	gyro_y_offset = 0;
	gyro_z_offset = 0;
	gyro_offset_calculated = 0;
	for (int i = 0; i < 2000; i++) {
		imu_read();
		if (i % 100 == 0)
			LL_GPIO_TogglePin(GPIOE, LED_Yellow_Pin);
		gyro_x_offset += gyroRaw.x;
		gyro_y_offset += gyroRaw.y;
		gyro_z_offset += gyroRaw.z;
		LL_mDelay(1);
	}
	gyro_x_offset /= 2000;
	gyro_y_offset /= 2000;
	gyro_z_offset /= 2000;
	gyro_offset_calculated = 1;
}

void calculate_acc_offset(void) {
	acc_x_offset = 0;
	acc_y_offset = 0;
	acc_offset_calculated = 0;
	for (int i = 0; i < 64; i++) {
		imu_read();
		if (i % 16 == 0)
			LL_GPIO_TogglePin(GPIOE, LED_Yellow_Pin);
		acc_x_offset += accRaw.x;
		acc_y_offset += accRaw.y;
		LL_mDelay(1);
	}
	acc_x_offset /= 64;
	acc_y_offset /= 64;

    //@B1:
	acc_x_offset = -4;
	acc_y_offset = -35;

	//@T1:
	acc_x_offset = -58;
	acc_y_offset = -48;

	acc_offset_calculated = 1;
}

void gyro_xyz_angular_velocity(void) {//131, 65.5, 32.8, 16.4
		angleSpeed.x = (angleSpeed.x * 0.7)	+ (((float) gyroRaw.x / DPS) * 0.3); //---------------------------------> a)0.2
		angleSpeed.y = (angleSpeed.y * 0.7)	+ (((float) gyroRaw.y / DPS) * 0.3);
		angleSpeed.z = (angleSpeed.z * 0.7)	+ (((float) gyroRaw.z / DPS) * 0.3);
}

void gyro_xyz_angle(void) {//131, 65.5, 32.8, 16.4
	gyroAngle.x += (float) gyroRaw.x * 0.001/DPS; //1.526717557251908e-5 -------------------------------------> b) X(dps) => X(dps) * 0.001 = X(d)
	gyroAngle.y += (float) gyroRaw.y * 0.001/DPS;
	gyroAngle.z += (float) gyroRaw.z * 0.001/DPS;

	if (gyroAngle.z < 0) gyroAngle.z += 360;
	else if (gyroAngle.z >= 360) gyroAngle.z -= 360;

	//Yaw_correction: 0.001/65.5 * M_PI/180 = 1.526717557251908e-5 * (M_PI/180) = 2.664624766751484e-7
	gyroAngle.x += gyroAngle.y * sin((float) gyroRaw.z * (0.001/DPS * M_PI/180));  //----------------------------> c)
	gyroAngle.y -= gyroAngle.x * sin((float) gyroRaw.z * (0.001/DPS * M_PI/180));
}

void accel_xy_angle(void) {
   Acc_total = sqrt((accRaw.x * accRaw.x) + (accRaw.y * accRaw.y) + (accRaw.z * accRaw.z));
   if (abs(accRaw.x) < Acc_total)  accAngle.x = asin((float) accRaw.x / Acc_total) *  (180 / M_PI);
   if (abs(accRaw.y) < Acc_total)  accAngle.y = asin((float) accRaw.y / Acc_total) *  (180 / M_PI);
}

void gyro_xyz_drift_correction(void) {
	gyroAngle.x = gyroAngle.x * 0.9996 + accAngle.x * 0.0004;
	gyroAngle.y = gyroAngle.y * 0.9996 + accAngle.y * 0.0004;
	gyroAngle.z = gyroAngle.z * 0.998 + compass_yaw * 0.002;//@DIY13-1
}

float angle_deviation(float current_yaw, float takeoff_yaw) {
	float val;
	float A = current_yaw - takeoff_yaw;
	if (abs(A) <= 180)
		val = A;
	else {
		if (A > 0) val = A - 360;
		if (A < 0) val = A + 360;
	}
	return val;
}

