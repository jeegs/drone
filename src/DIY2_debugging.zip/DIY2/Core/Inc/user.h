/*
 * user.h
 *
 *  Created on: January 01, 2022
 *      Author: JeeGS
 */

#include <stdio.h>
#include <math.h>

//@chapter2: debugging

extern uint8_t usart2_rx_flag;
extern uint8_t usart2_data;
extern uint8_t usart2_rx_cnt;
extern uint8_t usart2_rx_data[30];




